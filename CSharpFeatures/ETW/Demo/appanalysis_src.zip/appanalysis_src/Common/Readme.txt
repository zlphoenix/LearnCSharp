mc FirstEtw.man
mc -css MyNamespace FirstEtw.man
rc FirstEtw.rc

Add the generated .cs files to your project
Add the generated .res file to your project (properties - resource file)




