﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using Sql = System.Data.SQLite;

namespace ProducerApp
{
   class SqlDatabaseLayer : IDisposable
   {
      private Sql.SQLiteConnection m_connection;

      public SqlDatabaseLayer()
      {
         MyProvider.Eventing.FunctionTraceProvider.EventWriteCreateDbConnection();
         const string filename = @"..\sqlitedb\first.db";
         var fileInfo = new System.IO.FileInfo(filename);

         m_connection = new Sql.SQLiteConnection("Data Source=" + fileInfo.FullName + ";Version=3;");
         m_connection.Open();
      }

      public List<OrderSummary> GetOrderSummary()
      {
         const string sql = "select [OrderId], [CustomerId], [OrderlineId], [ProductId], [ProductDescription] from [OrderSummary];";
         var ds = new DataSet();
         var da = new Sql.SQLiteDataAdapter(sql, m_connection);

         da.Fill(ds);
         var list = new List<OrderSummary>();

         foreach (DataRow row in ds.Tables[0].Rows)
         {
            int orderid = (int)row[0];
            int customerid = (int)row[1];
            int ordelineid = (int)row[2];
            int productid = (int)row[3];
            string productdescription = (string)row[4];
            var r = new OrderSummary() { OrderId = orderid, CustomerId = customerid, OrderlineId = ordelineid, ProductId = productid, ProductDescription = productdescription };
            list.Add(r);
         }
         MyProvider.Eventing.FunctionTraceProvider.EventWriteSqlQuery(sql, list.Count);
         return list;
      }

      public List<Customer> GetAllCustomers()
      {

         const string sql = "select [Id], [Firstname], [Lastname], [Address] from [Customer];";
         var ds = new DataSet();
         var da = new Sql.SQLiteDataAdapter(sql, m_connection);

         da.Fill(ds);
         var list = new List<Customer>();

         foreach (DataRow row in ds.Tables[0].Rows)
         {
            int id = (int)row[0];
            string firstname = (string)row[1];
            string lastname = (string)row[2];
            string address = (string)row[3];
            var r = new Customer() { Id = id, Firstname = firstname, Lastname = lastname, Address = address };
            list.Add(r);
         }
         return list;
      }

      public int GetNumberOfOrders()
      {
         try
         {
            const string sql = "select count([Id]) from [Order];";
            var ds = new DataSet();
            var da = new Sql.SQLiteDataAdapter(sql, m_connection);

            da.Fill(ds);
            object result = ds.Tables[0].Rows[0][0];
            long numberOfOrders = (long)result;
            return (int)numberOfOrders;
         }
         catch (Exception ex)
         {
            throw;
         }
      }

      public void Dispose()
      {
         if (m_connection != null)
         {
            m_connection.Close();
         }
      }
   }
}
