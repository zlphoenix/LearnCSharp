﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace ProducerApp
{
   [ServiceContract]
   public interface IOrderSystem
   {
      [OperationContract]
      int NumberOfOrders();
      [OperationContract]
      string[] GetCustomers();
      [OperationContract]
      string[] GetOrderSummary();

      [OperationContract]
      string CrashMe();

   }

   public class OrderService : IOrderSystem
   {
      public string CrashMe()
      {
         try
         {
            MyProvider.Eventing.FunctionTraceProvider.EventWriteFunctionEntry();
            using (var dbLayer = new SqlDatabaseLayer())
            {
               var list = dbLayer.GetOrderSummary();
               var nonExistent = list[1000];
               return nonExistent.ProductDescription;
            }
         }
         catch (Exception ex)
         {
            MyProvider.Eventing.FunctionTraceProvider.EventWriteNetException(ex.Message);
            return string.Empty;
         }
         finally
         {
            MyProvider.Eventing.FunctionTraceProvider.EventWriteFuntionExit("CrashMe");
         }
      }

      public string[] GetOrderSummary()
      {
         try
         {
            MyProvider.Eventing.FunctionTraceProvider.EventWriteFunctionEntry();
            using (var dbLayer = new SqlDatabaseLayer())
            {
               var list = dbLayer.GetOrderSummary();
               var result = list.AsQueryable().Select(e => string.Format("{0}|{1}|{2}", e.OrderId, e.OrderlineId, e.ProductDescription));
               return result.ToArray();
            }
         }
         catch (Exception ex)
         {
            MyProvider.Eventing.FunctionTraceProvider.EventWriteNetException(ex.Message);
            return new string[] {};
         }
         finally
         {
            MyProvider.Eventing.FunctionTraceProvider.EventWriteFuntionExit("GetOrderSummary");
         }
      }

      public string[] GetCustomers()
      {
         try
         {
            MyProvider.Eventing.FunctionTraceProvider.EventWriteFunctionEntry();
            using (var dbLayer = new SqlDatabaseLayer())
            {
               var list = dbLayer.GetAllCustomers();
               var result = list.AsQueryable().Select(e => string.Format("{0} {1}", e.Firstname, e.Lastname));
               return result.ToArray();
            }
         }
         catch (Exception ex)
         {
            MyProvider.Eventing.FunctionTraceProvider.EventWriteNetException(ex.Message);
            return new string[] { };
         }
         finally
         {
            MyProvider.Eventing.FunctionTraceProvider.EventWriteFuntionExit("GetCustomers");
         }
      }
      
      public int NumberOfOrders()
      {
         try
         {
            MyProvider.Eventing.FunctionTraceProvider.EventWriteFunctionEntry();

            using (var dbLayer = new SqlDatabaseLayer())
            {
               return dbLayer.GetNumberOfOrders();
            }
         }
         catch (Exception ex)
         {
            MyProvider.Eventing.FunctionTraceProvider.EventWriteNetException(ex.Message);
            return -1;
         }
         finally
         {
            MyProvider.Eventing.FunctionTraceProvider.EventWriteFuntionExit("NumberOfOrders");
         }
      }
   }


   class Program
   {
      static void Main(string[] args)
      {
         Uri baseAddress = new Uri("http://localhost:8080/ordersystem");

         // Create the ServiceHost.
         using (ServiceHost host = new ServiceHost(typeof(OrderService), baseAddress))
         {
            // Enable metadata publishing.
            ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
            smb.HttpGetEnabled = true;
            smb.MetadataExporter.PolicyVersion = PolicyVersion.Policy15;
            host.Description.Behaviors.Add(smb);

            // Open the ServiceHost to start listening for messages. Since
            // no endpoints are explicitly configured, the runtime will create
            // one endpoint per base address for each service contract implemented
            // by the service.
            host.Open();

            Console.WriteLine("The service is ready at {0}", baseAddress);
            Console.WriteLine("Press <Enter> to stop the service.");
            Console.ReadLine();

            // Close the ServiceHost.
            host.Close();
         }

      }
   }
}
