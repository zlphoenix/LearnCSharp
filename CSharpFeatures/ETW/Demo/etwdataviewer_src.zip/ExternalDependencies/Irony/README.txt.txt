I removed unused libraries and samples projects from the folder.
Please download the fullsource from http://irony.codeplex.com


