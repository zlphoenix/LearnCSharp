﻿def add(x, y):
  x + y
  
add(3, 4)
  