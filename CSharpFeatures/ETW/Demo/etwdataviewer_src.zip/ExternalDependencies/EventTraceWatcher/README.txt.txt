I removed unused libraries and samples projects from the folder.
Please download the fullsource from http://archive.msdn.microsoft.com/EventTraceWatcher