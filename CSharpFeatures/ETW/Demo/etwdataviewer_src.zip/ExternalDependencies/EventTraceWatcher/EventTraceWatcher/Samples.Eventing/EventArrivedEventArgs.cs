﻿//------------------------------------------------------------------------------
// Author: Daniel Vasquez Lopez
//------------------------------------------------------------------------------

using System;

using Samples.Eventing.Interop;

namespace Samples.Eventing {

    public sealed class EventArrivedEventArgs : EventArgs {
        // Keep this event small.
        private readonly ushort eventId;
        private readonly PropertyBag properties;
        private readonly Exception error;
        
        // Added by EtwConsumer project
        private readonly EventHeader header;

        internal EventArrivedEventArgs(Exception error)
            : this(0/*eventId*/, new PropertyBag()) {
            this.error = error;
        }
        
        internal EventArrivedEventArgs(ushort eventId, EventHeader header, PropertyBag properties)
        {
            // Added by EtwConsumer project
            this.eventId = eventId;
            this.properties = properties;
            this.header = header;
        }

        internal EventHeader Header
        {
            // Added by EtwConsumer project
            get
            {
                return header;
            }
        }

        internal EventArrivedEventArgs(ushort eventId, PropertyBag properties) {
            this.eventId = eventId;
            this.properties = properties;
            this.header = new EventHeader();
        }

        public ushort EventId {
            get {
                return this.eventId;
            }
        }

        public PropertyBag Properties {
            get {
                return this.properties;
            }
        }

        public Exception Error {
            get {
                return this.error;
            }
        }
    }
}
