﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace EtwDataViewer
{
    public class ProcessItem : INotifyPropertyChanged
    {
        public int ProcessId { get; protected set; }
        public string ProductVersion { get; protected set; }
        private Process _process;
        
        public Process ProcessInfo
        {
            get { return _process; }
            set { SetProperty(ref _process, value); }
        }

        public void UpdateProcessInfo(Process process)
        {
            if (ProcessInfo == null || process == null)
                return;
            if (process.Id != ProcessInfo.Id)
                return;
            ProcessInfo = process;
        }

        public ProcessItem(int pId)
        {
            ProcessId = pId;
            IsActive = true;
            ProductVersion = string.Empty;            
        }

        public ProcessItem(Process process)
        {
            this.ProcessInfo = process;
            ProcessId = process.Id;
            IsActive = true;
            ProductVersion = string.Empty;
        }

        public ProcessItem(int pId, string productVersion)
        {
            ProcessId = pId;
            ProductVersion = productVersion;
            IsActive = true;
        }

        private bool _isActive;

        public bool IsActive
        { 
            get { return _isActive; }
            set { SetProperty(ref _isActive, value); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void SetProperty<T>(ref T field, T value, [CallerMemberName] string name = "")
        {
            if (!EqualityComparer<T>.Default.Equals(field, value))
            {
                field = value;
                var handler = PropertyChanged;
                if (handler != null)
                {
                    handler(this, new PropertyChangedEventArgs(name));
                }
            }
        }

    }
}
