﻿namespace ROOT.CIMV2.Win32 {
    using System;
    using System.ComponentModel;
    using System.Management;
    using System.Collections;
    using System.Globalization;
    
    
    // Functions ShouldSerialize<PropertyName> are functions used by VS property browser to check if a particular property has to be serialized. These functions are added for all ValueType properties ( properties of type Int32, BOOL etc.. which cannot be set to null). These functions use Is<PropertyName>Null function. These functions are also used in the TypeConverter implementation for the properties to check for NULL value of property so that an empty value can be shown in Property browser in case of Drag and Drop in Visual studio.
    // Functions Is<PropertyName>Null() are used to check if a property is NULL.
    // Functions Reset<PropertyName> are added for Nullable Read/Write properties. These functions are used by VS designer in property browser to set a property to NULL.
    // Every property added to the class for WMI property has attributes set to define its behavior in Visual Studio designer and also to define a TypeConverter to be used.
    // An Early Bound class generated for the WMI class.Win32_PerfFormattedData_PerfDisk_PhysicalDisk
    public class PerfFormattedData_PerfDisk_PhysicalDisk : System.ComponentModel.Component {
        
        // Private property to hold the WMI namespace in which the class resides.
        private static string CreatedWmiNamespace = "root\\CimV2";
        
        // Private property to hold the name of WMI class which created this class.
        private static string CreatedClassName = "Win32_PerfFormattedData_PerfDisk_PhysicalDisk";
        
        // Private member variable to hold the ManagementScope which is used by the various methods.
        private static System.Management.ManagementScope statMgmtScope = null;
        
        private ManagementSystemProperties PrivateSystemProperties;
        
        // Underlying lateBound WMI object.
        private System.Management.ManagementObject PrivateLateBoundObject;
        
        // Member variable to store the 'automatic commit' behavior for the class.
        private bool AutoCommitProp;
        
        // Private variable to hold the embedded property representing the instance.
        private System.Management.ManagementBaseObject embeddedObj;
        
        // The current WMI object used
        private System.Management.ManagementBaseObject curObj;
        
        // Flag to indicate if the instance is an embedded object.
        private bool isEmbedded;
        
        // Below are different overloads of constructors to initialize an instance of the class with a WMI object.
        public PerfFormattedData_PerfDisk_PhysicalDisk() {
            this.InitializeObject(null, null, null);
        }
        
        public PerfFormattedData_PerfDisk_PhysicalDisk(string keyName) {
            this.InitializeObject(null, new System.Management.ManagementPath(PerfFormattedData_PerfDisk_PhysicalDisk.ConstructPath(keyName)), null);
        }
        
        public PerfFormattedData_PerfDisk_PhysicalDisk(System.Management.ManagementScope mgmtScope, string keyName) {
            this.InitializeObject(((System.Management.ManagementScope)(mgmtScope)), new System.Management.ManagementPath(PerfFormattedData_PerfDisk_PhysicalDisk.ConstructPath(keyName)), null);
        }
        
        public PerfFormattedData_PerfDisk_PhysicalDisk(System.Management.ManagementPath path, System.Management.ObjectGetOptions getOptions) {
            this.InitializeObject(null, path, getOptions);
        }
        
        public PerfFormattedData_PerfDisk_PhysicalDisk(System.Management.ManagementScope mgmtScope, System.Management.ManagementPath path) {
            this.InitializeObject(mgmtScope, path, null);
        }
        
        public PerfFormattedData_PerfDisk_PhysicalDisk(System.Management.ManagementPath path) {
            this.InitializeObject(null, path, null);
        }
        
        public PerfFormattedData_PerfDisk_PhysicalDisk(System.Management.ManagementScope mgmtScope, System.Management.ManagementPath path, System.Management.ObjectGetOptions getOptions) {
            this.InitializeObject(mgmtScope, path, getOptions);
        }
        
        public PerfFormattedData_PerfDisk_PhysicalDisk(System.Management.ManagementObject theObject) {
            Initialize();
            if ((CheckIfProperClass(theObject) == true)) {
                PrivateLateBoundObject = theObject;
                PrivateSystemProperties = new ManagementSystemProperties(PrivateLateBoundObject);
                curObj = PrivateLateBoundObject;
            }
            else {
                throw new System.ArgumentException("Class name does not match.");
            }
        }
        
        public PerfFormattedData_PerfDisk_PhysicalDisk(System.Management.ManagementBaseObject theObject) {
            Initialize();
            if ((CheckIfProperClass(theObject) == true)) {
                embeddedObj = theObject;
                PrivateSystemProperties = new ManagementSystemProperties(theObject);
                curObj = embeddedObj;
                isEmbedded = true;
            }
            else {
                throw new System.ArgumentException("Class name does not match.");
            }
        }
        
        // Property returns the namespace of the WMI class.
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string OriginatingNamespace {
            get {
                return "root\\CimV2";
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ManagementClassName {
            get {
                string strRet = CreatedClassName;
                if ((curObj != null)) {
                    if ((curObj.ClassPath != null)) {
                        strRet = ((string)(curObj["__CLASS"]));
                        if (((strRet == null) 
                                    || (strRet == string.Empty))) {
                            strRet = CreatedClassName;
                        }
                    }
                }
                return strRet;
            }
        }
        
        // Property pointing to an embedded object to get System properties of the WMI object.
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ManagementSystemProperties SystemProperties {
            get {
                return PrivateSystemProperties;
            }
        }
        
        // Property returning the underlying lateBound object.
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public System.Management.ManagementBaseObject LateBoundObject {
            get {
                return curObj;
            }
        }
        
        // ManagementScope of the object.
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public System.Management.ManagementScope Scope {
            get {
                if ((isEmbedded == false)) {
                    return PrivateLateBoundObject.Scope;
                }
                else {
                    return null;
                }
            }
            set {
                if ((isEmbedded == false)) {
                    PrivateLateBoundObject.Scope = value;
                }
            }
        }
        
        // Property to show the commit behavior for the WMI object. If true, WMI object will be automatically saved after each property modification.(ie. Put() is called after modification of a property).
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool AutoCommit {
            get {
                return AutoCommitProp;
            }
            set {
                AutoCommitProp = value;
            }
        }
        
        // The ManagementPath of the underlying WMI object.
        [Browsable(true)]
        public System.Management.ManagementPath Path {
            get {
                if ((isEmbedded == false)) {
                    return PrivateLateBoundObject.Path;
                }
                else {
                    return null;
                }
            }
            set {
                if ((isEmbedded == false)) {
                    if ((CheckIfProperClass(null, value, null) != true)) {
                        throw new System.ArgumentException("Class name does not match.");
                    }
                    PrivateLateBoundObject.Path = value;
                }
            }
        }
        
        // Public static scope property which is used by the various methods.
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static System.Management.ManagementScope StaticScope {
            get {
                return statMgmtScope;
            }
            set {
                statMgmtScope = value;
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsAvgDiskBytesPerReadNull {
            get {
                if ((curObj["AvgDiskBytesPerRead"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Avg. Disk Bytes/Read is the average number of bytes transferred from the disk dur" +
            "ing read operations.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong AvgDiskBytesPerRead {
            get {
                if ((curObj["AvgDiskBytesPerRead"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["AvgDiskBytesPerRead"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsAvgDiskBytesPerTransferNull {
            get {
                if ((curObj["AvgDiskBytesPerTransfer"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Avg. Disk Bytes/Transfer is the average number of bytes transferred to or from th" +
            "e disk during write or read operations.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong AvgDiskBytesPerTransfer {
            get {
                if ((curObj["AvgDiskBytesPerTransfer"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["AvgDiskBytesPerTransfer"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsAvgDiskBytesPerWriteNull {
            get {
                if ((curObj["AvgDiskBytesPerWrite"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Avg. Disk Bytes/Write is the average number of bytes transferred to the disk duri" +
            "ng write operations.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong AvgDiskBytesPerWrite {
            get {
                if ((curObj["AvgDiskBytesPerWrite"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["AvgDiskBytesPerWrite"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsAvgDiskQueueLengthNull {
            get {
                if ((curObj["AvgDiskQueueLength"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Avg. Disk Queue Length is the average number of both read and write requests that" +
            " were queued for the selected disk during the sample interval.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong AvgDiskQueueLength {
            get {
                if ((curObj["AvgDiskQueueLength"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["AvgDiskQueueLength"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsAvgDiskReadQueueLengthNull {
            get {
                if ((curObj["AvgDiskReadQueueLength"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Avg. Disk Read Queue Length is the average number of read requests that were queu" +
            "ed for the selected disk during the sample interval.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong AvgDiskReadQueueLength {
            get {
                if ((curObj["AvgDiskReadQueueLength"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["AvgDiskReadQueueLength"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsAvgDisksecPerReadNull {
            get {
                if ((curObj["AvgDisksecPerRead"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Avg. Disk sec/Read is the average time, in seconds, of a read of data from the di" +
            "sk.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public uint AvgDisksecPerRead {
            get {
                if ((curObj["AvgDisksecPerRead"] == null)) {
                    return System.Convert.ToUInt32(0);
                }
                return ((uint)(curObj["AvgDisksecPerRead"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsAvgDisksecPerTransferNull {
            get {
                if ((curObj["AvgDisksecPerTransfer"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Avg. Disk sec/Transfer is the time, in seconds, of the average disk transfer.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public uint AvgDisksecPerTransfer {
            get {
                if ((curObj["AvgDisksecPerTransfer"] == null)) {
                    return System.Convert.ToUInt32(0);
                }
                return ((uint)(curObj["AvgDisksecPerTransfer"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsAvgDisksecPerWriteNull {
            get {
                if ((curObj["AvgDisksecPerWrite"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Avg. Disk sec/Write is the average time, in seconds, of a write of data to the di" +
            "sk.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public uint AvgDisksecPerWrite {
            get {
                if ((curObj["AvgDisksecPerWrite"] == null)) {
                    return System.Convert.ToUInt32(0);
                }
                return ((uint)(curObj["AvgDisksecPerWrite"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsAvgDiskWriteQueueLengthNull {
            get {
                if ((curObj["AvgDiskWriteQueueLength"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Avg. Disk Write Queue Length is the average number of write requests that were qu" +
            "eued for the selected disk during the sample interval.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong AvgDiskWriteQueueLength {
            get {
                if ((curObj["AvgDiskWriteQueueLength"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["AvgDiskWriteQueueLength"]));
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("A short textual description (one-line string) for the statistic or metric.")]
        public string Caption {
            get {
                return ((string)(curObj["Caption"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsCurrentDiskQueueLengthNull {
            get {
                if ((curObj["CurrentDiskQueueLength"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description(@"Current Disk Queue Length is the number of requests outstanding on the disk at the time the performance data is collected. It also includes requests in service at the time of the collection. This is a instantaneous snapshot, not an average over the time interval. Multi-spindle disk devices can have multiple requests that are active at one time, but other concurrent requests are awaiting service. This counter might reflect a transitory high or low queue length, but if there is a sustained load on the disk drive, it is likely that this will be consistently high. Requests experience delays proportional to the length of this queue minus the number of spindles on the disks. For good performance, this difference should average less than two.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public uint CurrentDiskQueueLength {
            get {
                if ((curObj["CurrentDiskQueueLength"] == null)) {
                    return System.Convert.ToUInt32(0);
                }
                return ((uint)(curObj["CurrentDiskQueueLength"]));
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("A textual description of the statistic or metric.")]
        public string Description {
            get {
                return ((string)(curObj["Description"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsDiskBytesPersecNull {
            get {
                if ((curObj["DiskBytesPersec"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Disk Bytes/sec is the rate bytes are transferred to or from the disk during write" +
            " or read operations.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong DiskBytesPersec {
            get {
                if ((curObj["DiskBytesPersec"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["DiskBytesPersec"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsDiskReadBytesPersecNull {
            get {
                if ((curObj["DiskReadBytesPersec"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Disk Read Bytes/sec is the rate at which bytes are transferred from the disk duri" +
            "ng read operations.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong DiskReadBytesPersec {
            get {
                if ((curObj["DiskReadBytesPersec"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["DiskReadBytesPersec"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsDiskReadsPersecNull {
            get {
                if ((curObj["DiskReadsPersec"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Disk Reads/sec is the rate of read operations on the disk.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public uint DiskReadsPersec {
            get {
                if ((curObj["DiskReadsPersec"] == null)) {
                    return System.Convert.ToUInt32(0);
                }
                return ((uint)(curObj["DiskReadsPersec"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsDiskTransfersPersecNull {
            get {
                if ((curObj["DiskTransfersPersec"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Disk Transfers/sec is the rate of read and write operations on the disk.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public uint DiskTransfersPersec {
            get {
                if ((curObj["DiskTransfersPersec"] == null)) {
                    return System.Convert.ToUInt32(0);
                }
                return ((uint)(curObj["DiskTransfersPersec"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsDiskWriteBytesPersecNull {
            get {
                if ((curObj["DiskWriteBytesPersec"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Disk Write Bytes/sec is rate at which bytes are transferred to the disk during wr" +
            "ite operations.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong DiskWriteBytesPersec {
            get {
                if ((curObj["DiskWriteBytesPersec"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["DiskWriteBytesPersec"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsDiskWritesPersecNull {
            get {
                if ((curObj["DiskWritesPersec"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Disk Writes/sec is the rate of write operations on the disk.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public uint DiskWritesPersec {
            get {
                if ((curObj["DiskWritesPersec"] == null)) {
                    return System.Convert.ToUInt32(0);
                }
                return ((uint)(curObj["DiskWritesPersec"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsFrequency_ObjectNull {
            get {
                if ((curObj["Frequency_Object"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong Frequency_Object {
            get {
                if ((curObj["Frequency_Object"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["Frequency_Object"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsFrequency_PerfTimeNull {
            get {
                if ((curObj["Frequency_PerfTime"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong Frequency_PerfTime {
            get {
                if ((curObj["Frequency_PerfTime"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["Frequency_PerfTime"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsFrequency_Sys100NSNull {
            get {
                if ((curObj["Frequency_Sys100NS"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong Frequency_Sys100NS {
            get {
                if ((curObj["Frequency_Sys100NS"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["Frequency_Sys100NS"]));
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The Name property defines the label by which the statistic or metric is known. Wh" +
            "en subclassed, the property can be overridden to be a Key property. ")]
        public string Name {
            get {
                return ((string)(curObj["Name"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsPercentDiskReadTimeNull {
            get {
                if ((curObj["PercentDiskReadTime"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("% Disk Read Time is the percentage of elapsed time that the selected disk drive w" +
            "as busy servicing read requests.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong PercentDiskReadTime {
            get {
                if ((curObj["PercentDiskReadTime"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["PercentDiskReadTime"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsPercentDiskTimeNull {
            get {
                if ((curObj["PercentDiskTime"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("% Disk Time is the percentage of elapsed time that the selected disk drive was bu" +
            "sy servicing read or write requests.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong PercentDiskTime {
            get {
                if ((curObj["PercentDiskTime"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["PercentDiskTime"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsPercentDiskWriteTimeNull {
            get {
                if ((curObj["PercentDiskWriteTime"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("% Disk Write Time is the percentage of elapsed time that the selected disk drive " +
            "was busy servicing write requests.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong PercentDiskWriteTime {
            get {
                if ((curObj["PercentDiskWriteTime"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["PercentDiskWriteTime"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsPercentIdleTimeNull {
            get {
                if ((curObj["PercentIdleTime"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("% Idle Time reports the percentage of time during the sample interval that the di" +
            "sk was idle.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong PercentIdleTime {
            get {
                if ((curObj["PercentIdleTime"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["PercentIdleTime"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsSplitIOPerSecNull {
            get {
                if ((curObj["SplitIOPerSec"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Split IO/Sec reports the rate at which I/Os to the disk were split into multiple " +
            "I/Os. A split I/O may result from requesting data of a size that is too large to" +
            " fit into a single I/O or that the disk is fragmented.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public uint SplitIOPerSec {
            get {
                if ((curObj["SplitIOPerSec"] == null)) {
                    return System.Convert.ToUInt32(0);
                }
                return ((uint)(curObj["SplitIOPerSec"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsTimestamp_ObjectNull {
            get {
                if ((curObj["Timestamp_Object"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong Timestamp_Object {
            get {
                if ((curObj["Timestamp_Object"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["Timestamp_Object"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsTimestamp_PerfTimeNull {
            get {
                if ((curObj["Timestamp_PerfTime"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong Timestamp_PerfTime {
            get {
                if ((curObj["Timestamp_PerfTime"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["Timestamp_PerfTime"]));
            }
        }
        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsTimestamp_Sys100NSNull {
            get {
                if ((curObj["Timestamp_Sys100NS"] == null)) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ulong Timestamp_Sys100NS {
            get {
                if ((curObj["Timestamp_Sys100NS"] == null)) {
                    return System.Convert.ToUInt64(0);
                }
                return ((ulong)(curObj["Timestamp_Sys100NS"]));
            }
        }
        
        private bool CheckIfProperClass(System.Management.ManagementScope mgmtScope, System.Management.ManagementPath path, System.Management.ObjectGetOptions OptionsParam) {
            if (((path != null) 
                        && (string.Compare(path.ClassName, this.ManagementClassName, true, System.Globalization.CultureInfo.InvariantCulture) == 0))) {
                return true;
            }
            else {
                return CheckIfProperClass(new System.Management.ManagementObject(mgmtScope, path, OptionsParam));
            }
        }
        
        private bool CheckIfProperClass(System.Management.ManagementBaseObject theObj) {
            if (((theObj != null) 
                        && (string.Compare(((string)(theObj["__CLASS"])), this.ManagementClassName, true, System.Globalization.CultureInfo.InvariantCulture) == 0))) {
                return true;
            }
            else {
                System.Array parentClasses = ((System.Array)(theObj["__DERIVATION"]));
                if ((parentClasses != null)) {
                    int count = 0;
                    for (count = 0; (count < parentClasses.Length); count = (count + 1)) {
                        if ((string.Compare(((string)(parentClasses.GetValue(count))), this.ManagementClassName, true, System.Globalization.CultureInfo.InvariantCulture) == 0)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
        
        private bool ShouldSerializeAvgDiskBytesPerRead() {
            if ((this.IsAvgDiskBytesPerReadNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeAvgDiskBytesPerTransfer() {
            if ((this.IsAvgDiskBytesPerTransferNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeAvgDiskBytesPerWrite() {
            if ((this.IsAvgDiskBytesPerWriteNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeAvgDiskQueueLength() {
            if ((this.IsAvgDiskQueueLengthNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeAvgDiskReadQueueLength() {
            if ((this.IsAvgDiskReadQueueLengthNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeAvgDisksecPerRead() {
            if ((this.IsAvgDisksecPerReadNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeAvgDisksecPerTransfer() {
            if ((this.IsAvgDisksecPerTransferNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeAvgDisksecPerWrite() {
            if ((this.IsAvgDisksecPerWriteNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeAvgDiskWriteQueueLength() {
            if ((this.IsAvgDiskWriteQueueLengthNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeCurrentDiskQueueLength() {
            if ((this.IsCurrentDiskQueueLengthNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeDiskBytesPersec() {
            if ((this.IsDiskBytesPersecNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeDiskReadBytesPersec() {
            if ((this.IsDiskReadBytesPersecNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeDiskReadsPersec() {
            if ((this.IsDiskReadsPersecNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeDiskTransfersPersec() {
            if ((this.IsDiskTransfersPersecNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeDiskWriteBytesPersec() {
            if ((this.IsDiskWriteBytesPersecNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeDiskWritesPersec() {
            if ((this.IsDiskWritesPersecNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeFrequency_Object() {
            if ((this.IsFrequency_ObjectNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeFrequency_PerfTime() {
            if ((this.IsFrequency_PerfTimeNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeFrequency_Sys100NS() {
            if ((this.IsFrequency_Sys100NSNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializePercentDiskReadTime() {
            if ((this.IsPercentDiskReadTimeNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializePercentDiskTime() {
            if ((this.IsPercentDiskTimeNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializePercentDiskWriteTime() {
            if ((this.IsPercentDiskWriteTimeNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializePercentIdleTime() {
            if ((this.IsPercentIdleTimeNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeSplitIOPerSec() {
            if ((this.IsSplitIOPerSecNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeTimestamp_Object() {
            if ((this.IsTimestamp_ObjectNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeTimestamp_PerfTime() {
            if ((this.IsTimestamp_PerfTimeNull == false)) {
                return true;
            }
            return false;
        }
        
        private bool ShouldSerializeTimestamp_Sys100NS() {
            if ((this.IsTimestamp_Sys100NSNull == false)) {
                return true;
            }
            return false;
        }
        
        [Browsable(true)]
        public void CommitObject() {
            if ((isEmbedded == false)) {
                PrivateLateBoundObject.Put();
            }
        }
        
        [Browsable(true)]
        public void CommitObject(System.Management.PutOptions putOptions) {
            if ((isEmbedded == false)) {
                PrivateLateBoundObject.Put(putOptions);
            }
        }
        
        private void Initialize() {
            AutoCommitProp = true;
            isEmbedded = false;
        }
        
        private static string ConstructPath(string keyName) {
            string strPath = "root\\CimV2:Win32_PerfFormattedData_PerfDisk_PhysicalDisk";
            strPath = string.Concat(strPath, string.Concat(".Name=", string.Concat("\"", string.Concat(keyName, "\""))));
            return strPath;
        }
        
        private void InitializeObject(System.Management.ManagementScope mgmtScope, System.Management.ManagementPath path, System.Management.ObjectGetOptions getOptions) {
            Initialize();
            if ((path != null)) {
                if ((CheckIfProperClass(mgmtScope, path, getOptions) != true)) {
                    throw new System.ArgumentException("Class name does not match.");
                }
            }
            PrivateLateBoundObject = new System.Management.ManagementObject(mgmtScope, path, getOptions);
            PrivateSystemProperties = new ManagementSystemProperties(PrivateLateBoundObject);
            curObj = PrivateLateBoundObject;
        }
        
        // Different overloads of GetInstances() help in enumerating instances of the WMI class.
        public static PerfFormattedData_PerfDisk_PhysicalDiskCollection GetInstances() {
            return GetInstances(null, null, null);
        }
        
        public static PerfFormattedData_PerfDisk_PhysicalDiskCollection GetInstances(string condition) {
            return GetInstances(null, condition, null);
        }
        
        public static PerfFormattedData_PerfDisk_PhysicalDiskCollection GetInstances(string[] selectedProperties) {
            return GetInstances(null, null, selectedProperties);
        }
        
        public static PerfFormattedData_PerfDisk_PhysicalDiskCollection GetInstances(string condition, string[] selectedProperties) {
            return GetInstances(null, condition, selectedProperties);
        }
        
        public static PerfFormattedData_PerfDisk_PhysicalDiskCollection GetInstances(System.Management.ManagementScope mgmtScope, System.Management.EnumerationOptions enumOptions) {
            if ((mgmtScope == null)) {
                if ((statMgmtScope == null)) {
                    mgmtScope = new System.Management.ManagementScope();
                    mgmtScope.Path.NamespacePath = "root\\CimV2";
                }
                else {
                    mgmtScope = statMgmtScope;
                }
            }
            System.Management.ManagementPath pathObj = new System.Management.ManagementPath();
            pathObj.ClassName = "Win32_PerfFormattedData_PerfDisk_PhysicalDisk";
            pathObj.NamespacePath = "root\\CimV2";
            System.Management.ManagementClass clsObject = new System.Management.ManagementClass(mgmtScope, pathObj, null);
            if ((enumOptions == null)) {
                enumOptions = new System.Management.EnumerationOptions();
                enumOptions.EnsureLocatable = true;
            }
            return new PerfFormattedData_PerfDisk_PhysicalDiskCollection(clsObject.GetInstances(enumOptions));
        }
        
        public static PerfFormattedData_PerfDisk_PhysicalDiskCollection GetInstances(System.Management.ManagementScope mgmtScope, string condition) {
            return GetInstances(mgmtScope, condition, null);
        }
        
        public static PerfFormattedData_PerfDisk_PhysicalDiskCollection GetInstances(System.Management.ManagementScope mgmtScope, string[] selectedProperties) {
            return GetInstances(mgmtScope, null, selectedProperties);
        }
        
        public static PerfFormattedData_PerfDisk_PhysicalDiskCollection GetInstances(System.Management.ManagementScope mgmtScope, string condition, string[] selectedProperties) {
            if ((mgmtScope == null)) {
                if ((statMgmtScope == null)) {
                    mgmtScope = new System.Management.ManagementScope();
                    mgmtScope.Path.NamespacePath = "root\\CimV2";
                }
                else {
                    mgmtScope = statMgmtScope;
                }
            }
            System.Management.ManagementObjectSearcher ObjectSearcher = new System.Management.ManagementObjectSearcher(mgmtScope, new SelectQuery("Win32_PerfFormattedData_PerfDisk_PhysicalDisk", condition, selectedProperties));
            System.Management.EnumerationOptions enumOptions = new System.Management.EnumerationOptions();
            enumOptions.EnsureLocatable = true;
            ObjectSearcher.Options = enumOptions;
            return new PerfFormattedData_PerfDisk_PhysicalDiskCollection(ObjectSearcher.Get());
        }
        
        [Browsable(true)]
        public static PerfFormattedData_PerfDisk_PhysicalDisk CreateInstance() {
            System.Management.ManagementScope mgmtScope = null;
            if ((statMgmtScope == null)) {
                mgmtScope = new System.Management.ManagementScope();
                mgmtScope.Path.NamespacePath = CreatedWmiNamespace;
            }
            else {
                mgmtScope = statMgmtScope;
            }
            System.Management.ManagementPath mgmtPath = new System.Management.ManagementPath(CreatedClassName);
            System.Management.ManagementClass tmpMgmtClass = new System.Management.ManagementClass(mgmtScope, mgmtPath, null);
            return new PerfFormattedData_PerfDisk_PhysicalDisk(tmpMgmtClass.CreateInstance());
        }
        
        [Browsable(true)]
        public void Delete() {
            PrivateLateBoundObject.Delete();
        }
        
        // Enumerator implementation for enumerating instances of the class.
        public class PerfFormattedData_PerfDisk_PhysicalDiskCollection : object, ICollection {
            
            private ManagementObjectCollection privColObj;
            
            public PerfFormattedData_PerfDisk_PhysicalDiskCollection(ManagementObjectCollection objCollection) {
                privColObj = objCollection;
            }
            
            public virtual int Count {
                get {
                    return privColObj.Count;
                }
            }
            
            public virtual bool IsSynchronized {
                get {
                    return privColObj.IsSynchronized;
                }
            }
            
            public virtual object SyncRoot {
                get {
                    return this;
                }
            }
            
            public virtual void CopyTo(System.Array array, int index) {
                privColObj.CopyTo(array, index);
                int nCtr;
                for (nCtr = 0; (nCtr < array.Length); nCtr = (nCtr + 1)) {
                    array.SetValue(new PerfFormattedData_PerfDisk_PhysicalDisk(((System.Management.ManagementObject)(array.GetValue(nCtr)))), nCtr);
                }
            }
            
            public virtual System.Collections.IEnumerator GetEnumerator() {
                return new PerfFormattedData_PerfDisk_PhysicalDiskEnumerator(privColObj.GetEnumerator());
            }
            
            public class PerfFormattedData_PerfDisk_PhysicalDiskEnumerator : object, System.Collections.IEnumerator {
                
                private ManagementObjectCollection.ManagementObjectEnumerator privObjEnum;
                
                public PerfFormattedData_PerfDisk_PhysicalDiskEnumerator(ManagementObjectCollection.ManagementObjectEnumerator objEnum) {
                    privObjEnum = objEnum;
                }
                
                public virtual object Current {
                    get {
                        return new PerfFormattedData_PerfDisk_PhysicalDisk(((System.Management.ManagementObject)(privObjEnum.Current)));
                    }
                }
                
                public virtual bool MoveNext() {
                    return privObjEnum.MoveNext();
                }
                
                public virtual void Reset() {
                    privObjEnum.Reset();
                }
            }
        }
        
        // TypeConverter to handle null values for ValueType properties
        public class WMIValueTypeConverter : TypeConverter {
            
            private TypeConverter baseConverter;
            
            private System.Type baseType;
            
            public WMIValueTypeConverter(System.Type inBaseType) {
                baseConverter = TypeDescriptor.GetConverter(inBaseType);
                baseType = inBaseType;
            }
            
            public override bool CanConvertFrom(System.ComponentModel.ITypeDescriptorContext context, System.Type srcType) {
                return baseConverter.CanConvertFrom(context, srcType);
            }
            
            public override bool CanConvertTo(System.ComponentModel.ITypeDescriptorContext context, System.Type destinationType) {
                return baseConverter.CanConvertTo(context, destinationType);
            }
            
            public override object ConvertFrom(System.ComponentModel.ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value) {
                return baseConverter.ConvertFrom(context, culture, value);
            }
            
            public override object CreateInstance(System.ComponentModel.ITypeDescriptorContext context, System.Collections.IDictionary dictionary) {
                return baseConverter.CreateInstance(context, dictionary);
            }
            
            public override bool GetCreateInstanceSupported(System.ComponentModel.ITypeDescriptorContext context) {
                return baseConverter.GetCreateInstanceSupported(context);
            }
            
            public override PropertyDescriptorCollection GetProperties(System.ComponentModel.ITypeDescriptorContext context, object value, System.Attribute[] attributeVar) {
                return baseConverter.GetProperties(context, value, attributeVar);
            }
            
            public override bool GetPropertiesSupported(System.ComponentModel.ITypeDescriptorContext context) {
                return baseConverter.GetPropertiesSupported(context);
            }
            
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(System.ComponentModel.ITypeDescriptorContext context) {
                return baseConverter.GetStandardValues(context);
            }
            
            public override bool GetStandardValuesExclusive(System.ComponentModel.ITypeDescriptorContext context) {
                return baseConverter.GetStandardValuesExclusive(context);
            }
            
            public override bool GetStandardValuesSupported(System.ComponentModel.ITypeDescriptorContext context) {
                return baseConverter.GetStandardValuesSupported(context);
            }
            
            public override object ConvertTo(System.ComponentModel.ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value, System.Type destinationType) {
                if ((baseType.BaseType == typeof(System.Enum))) {
                    if ((value.GetType() == destinationType)) {
                        return value;
                    }
                    if ((((value == null) 
                                && (context != null)) 
                                && (context.PropertyDescriptor.ShouldSerializeValue(context.Instance) == false))) {
                        return  "NULL_ENUM_VALUE" ;
                    }
                    return baseConverter.ConvertTo(context, culture, value, destinationType);
                }
                if (((baseType == typeof(bool)) 
                            && (baseType.BaseType == typeof(System.ValueType)))) {
                    if ((((value == null) 
                                && (context != null)) 
                                && (context.PropertyDescriptor.ShouldSerializeValue(context.Instance) == false))) {
                        return "";
                    }
                    return baseConverter.ConvertTo(context, culture, value, destinationType);
                }
                if (((context != null) 
                            && (context.PropertyDescriptor.ShouldSerializeValue(context.Instance) == false))) {
                    return "";
                }
                return baseConverter.ConvertTo(context, culture, value, destinationType);
            }
        }
        
        // Embedded class to represent WMI system Properties.
        [TypeConverter(typeof(System.ComponentModel.ExpandableObjectConverter))]
        public class ManagementSystemProperties {
            
            private System.Management.ManagementBaseObject PrivateLateBoundObject;
            
            public ManagementSystemProperties(System.Management.ManagementBaseObject ManagedObject) {
                PrivateLateBoundObject = ManagedObject;
            }
            
            [Browsable(true)]
            public int GENUS {
                get {
                    return ((int)(PrivateLateBoundObject["__GENUS"]));
                }
            }
            
            [Browsable(true)]
            public string CLASS {
                get {
                    return ((string)(PrivateLateBoundObject["__CLASS"]));
                }
            }
            
            [Browsable(true)]
            public string SUPERCLASS {
                get {
                    return ((string)(PrivateLateBoundObject["__SUPERCLASS"]));
                }
            }
            
            [Browsable(true)]
            public string DYNASTY {
                get {
                    return ((string)(PrivateLateBoundObject["__DYNASTY"]));
                }
            }
            
            [Browsable(true)]
            public string RELPATH {
                get {
                    return ((string)(PrivateLateBoundObject["__RELPATH"]));
                }
            }
            
            [Browsable(true)]
            public int PROPERTY_COUNT {
                get {
                    return ((int)(PrivateLateBoundObject["__PROPERTY_COUNT"]));
                }
            }
            
            [Browsable(true)]
            public string[] DERIVATION {
                get {
                    return ((string[])(PrivateLateBoundObject["__DERIVATION"]));
                }
            }
            
            [Browsable(true)]
            public string SERVER {
                get {
                    return ((string)(PrivateLateBoundObject["__SERVER"]));
                }
            }
            
            [Browsable(true)]
            public string NAMESPACE {
                get {
                    return ((string)(PrivateLateBoundObject["__NAMESPACE"]));
                }
            }
            
            [Browsable(true)]
            public string PATH {
                get {
                    return ((string)(PrivateLateBoundObject["__PATH"]));
                }
            }
        }
    }
}
