﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

using EtwConsumer;
using EtwDataViewer.Common;

namespace EtwDataViewer
{
    public class EtwDataEventToEtwDataEventItemConverter : IValueConverter
    {
        List<Dictionary<int, string>> _eventNameDictionary = new List<Dictionary<int,string>>();

        List<EtwProvider> _providers = new List<EtwProvider>();
        Dictionary<Guid, int> _providerLookup = new Dictionary<Guid, int>();

        public bool ShowTimestamp { get; set; }

        public EtwDataEventToEtwDataEventItemConverter()
        {                  
        }

        private EtwDecoder _decoder = new EtwDecoder();
        public EtwDecoder Decoder
        { 
            get { return _decoder;} 
            set
            {
                _decoder = value;
                _providers = _decoder.Providers();
                _eventNameDictionary.Clear();
                _providerLookup.Clear();
                for (int i=0;i<_providers.Count;i++)
                {
                    // populate dictionary
                    // and create a mapping from GUID to index to the other dictionary
                    var provider = _providers[i];
                    _eventNameDictionary.Add(_decoder.DecodeEvents(provider.ProviderId));
                    _providerLookup.Add(provider.ProviderId, i);
                }
            }
        }


        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            try
            {
                var node = value as EtwDataEventItem;

                var eventData = node.Content;
                var providerId = eventData.Header.ProviderId;
                int index = _providerLookup[providerId];
                var eventNames = _eventNameDictionary[index];
            
                var sb = new StringBuilder();
                if (ShowTimestamp)
                {
                    sb.Append(eventData.Header.TimeStamp);
                    sb.Append("\t");
                }
                sb.Append(eventNames[eventData.Header.EventId]);
                return sb.ToString();
            }
            catch
            {
                return "not found";
            }         
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}

