﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.Serialization;
//using System.Runtime.Serialization.Json;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Diagnostics;

using System.Runtime.InteropServices;
using System.Windows.Threading;

using EtwDataViewer.Common;
using EtwConsumer;
using EtwDataViewer.Plugin;

namespace EtwDataViewer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // The etw events are application specific
        // The analysis is hard coded for the demo app

        private IEtwDataAnalyzer _demoAnalyzer = new DemoPlugin.EtwDataAnalyzerDemo();



        private BackgroundQueue _workerQueue = new BackgroundQueue();
        private readonly DispatcherTimer _refreshTimer = new DispatcherTimer();

        List<EtwDataEvent> _allEvents = new List<EtwDataEvent>();

        ObservableCollection<EtwDataEventItem> _filteredEvents = new ObservableCollection<EtwDataEventItem>();
        public ObservableCollection<EtwDataEventItem> FilteredEvents { get { return _filteredEvents; } }

        public readonly ObservableCollection<EtwEventItem> _eventTypeNames = new ObservableCollection<EtwEventItem>();
        public ObservableCollection<EtwEventItem> EventTypeNames { get { return _eventTypeNames; } }

        public readonly ObservableCollection<NodeItem<string>> _foundTableNames = new ObservableCollection<NodeItem<string>>();
  
        private ObservableCollection<NodeItem<WmiDataType>> _wmiDataPerProcess = new ObservableCollection<NodeItem<WmiDataType>>();
        public ObservableCollection<NodeItem<WmiDataType>> WmiDataPerProcess
        {
            get { return _wmiDataPerProcess; }
        }

        private ObservableCollection<NodeItem<string>> _wmiDataGlobal = new ObservableCollection<NodeItem<string>>();
        public ObservableCollection<NodeItem<string>> WmiDataGlobal
        {
            get { return _wmiDataGlobal; }
        }

        private ObservableCollection<NodeItem<string>> _sqlCommands = new ObservableCollection<NodeItem<string>>();
        public ObservableCollection<NodeItem<string>> SqlCommands
        {
            get { return _sqlCommands; }
        }

        private ObservableCollection<NodeItem<string>> _tableNames = new ObservableCollection<NodeItem<string>>();
        public ObservableCollection<NodeItem<string>> TableNames
        {
            get { return _tableNames; }
        }

        List<string> _providerFilenames = new List<string>();

        public bool HasLoadedManifest { get { return GlobalEtwDecoder.IsValid; } }
        public bool CanStart
        { 
            get 
            {
                if (_dataListeners.Count == 0)
                    return false;
                if (!GlobalEtwDecoder.IsValid)
                    return false;
                bool canStart = !_dataListeners.First().IsRunning;               

                return canStart;
            } 
        }

        public bool IsRunning
        {
            get
            {
                if (_dataListeners.Count == 0)
                    return false;
                if (!GlobalEtwDecoder.IsValid)
                    return false;
                bool running = _dataListeners.First().IsRunning;

                return running;
            }
        }

        public bool HasData
        {
            get
            {
                return _allEvents.Count != 0;
            }
        }

        private bool UpdateWmi(ROOT.CIMV2.Win32.PerfFormattedData_PerfProc_Process instance)
        {
            var wmi = _wmiDataPerProcess.FirstOrDefault(n => n.Content.IDProcess == instance.IDProcess);
            if (wmi == null)
                return false;

            wmi.Content = new WmiDataType
            {
                IDProcess = instance.IDProcess,
                PrivateBytes = instance.PrivateBytes
            };
            return true;
        }

        private void CollectWmiDataPerProcess()
        {   
            //var result = new List<System.Diagnostics.Process>();
            _providerFilenames.ForEach(filename =>
            {
                var file = new System.IO.FileInfo(filename);
                var shortFilename = filename.Replace(file.Extension, string.Empty).ToLower();

                // appname appears as 'appname', 'appname#1', 'appname#2', etc
                // The syntax is very SQL like
                // But it is called WQL, WMI Query Language
                var condition = string.Format("Name LIKE '{0}%'", shortFilename);

                var vbusInstances =
                    ROOT.CIMV2.Win32.PerfFormattedData_PerfProc_Process.GetInstances(condition)
                        .Cast<ROOT.CIMV2.Win32.PerfFormattedData_PerfProc_Process>().ToList();

                Dispatcher.Invoke(() =>
                {
                    int count = vbusInstances.Count;
                    foreach (var instance in vbusInstances)
                    {
                        if (UpdateWmi(instance))
                        {
                            ;// updated
                        }
                        else
                        {
                            _wmiDataPerProcess.Add(new NodeItem<WmiDataType>(new WmiDataType { IDProcess = instance.IDProcess, PrivateBytes = instance.PrivateBytes }));
                        }
                    }
                });
            });
        }

        private void UpdateGlobalCounters()
        {

            var diskInstance =
                ROOT.CIMV2.Win32.PerfFormattedData_PerfDisk_PhysicalDisk.GetInstances()
                    .Cast<ROOT.CIMV2.Win32.PerfFormattedData_PerfDisk_PhysicalDisk>().FirstOrDefault();
            var networkInstance =
                ROOT.CIMV2.Win32.PerfFormattedData_Tcpip_NetworkInterface.GetInstances()
                .Cast<ROOT.CIMV2.Win32.PerfFormattedData_Tcpip_NetworkInterface>().FirstOrDefault();
            
            Dispatcher.Invoke(() =>
            {
                _wmiDataGlobal.Clear();
                if (diskInstance != null)
                {
                    int throughput = (int)diskInstance.DiskBytesPersec / 1024;
                    _wmiDataGlobal.Add(new NodeItem<string>("Disk io kb/s : " + throughput));
                }
                if (networkInstance != null)
                {
                    int throughput = (int)networkInstance.BytesTotalPersec / 1024;
                    _wmiDataGlobal.Add(new NodeItem<string>("Network io kb/s : " + throughput));
                }
            });

        }

        private void UpdateWmi()
        {
            UpdateGlobalCounters();
            CollectWmiDataPerProcess();
        }


        private void UpdateMenuStatus()
        {
            StartCommand.IsEnabled = false;
            StopCommand.IsEnabled = false;
            SaveCommand.IsEnabled = false;
            LoadCommand.IsEnabled = false;
            LoadManifestCommand.IsEnabled = false;
            RunDemoCommand.IsEnabled = false;
            ClearCommand.IsEnabled = false;

            RebuildTreeCommand.IsEnabled = true;
            ClearCommand.IsEnabled = true;

            if (!HasLoadedManifest)
            {
                LoadManifestCommand.IsEnabled = true;
                RunDemoCommand.IsEnabled = true;
            }
            else if (IsRunning)
            {
                StopCommand.IsEnabled = true;
                SaveCommand.IsEnabled = true;
                if (HasData)
                {
                    ClearCommand.IsEnabled = true;
                    RebuildTreeCommand.IsEnabled = true;
                }
            }
            else if (HasData && !IsRunning)
            {
                StartCommand.IsEnabled = true;
                SaveCommand.IsEnabled = true;
                LoadManifestCommand.IsEnabled = true;
                RunDemoCommand.IsEnabled = true;
                ClearCommand.IsEnabled = true;
                RebuildTreeCommand.IsEnabled = true;
            }
            else if (CanStart)
            {
                StartCommand.IsEnabled = true;
                LoadManifestCommand.IsEnabled = true;
                RunDemoCommand.IsEnabled = true;
                LoadCommand.IsEnabled = true;
            }
            else
            {
                // impossible to reach?
                throw new NotImplementedException();
            }
        }

        public NodeItem<ICommand> LoadCommand { get; protected set; }
        public NodeItem<ICommand> SaveCommand { get; protected set; }
        public NodeItem<ICommand> RebuildTreeCommand { get; protected set; }
        public NodeItem<ICommand> ClearCommand { get; protected set; }
        public NodeItem<ICommand> HelpCommand { get; protected set; }
        public NodeItem<ICommand> AboutCommand { get; protected set; }

        public NodeItem<ICommand> StartCommand { get; protected set; }
        public NodeItem<ICommand> StopCommand { get; protected set; }
        public NodeItem<ICommand> LoadManifestCommand { get; protected set; }
        public NodeItem<ICommand> RunDemoCommand { get; protected set; }
        public NodeItem<ICommand> ToggleTimestampCommand { get; protected set; }

        private EtwDecoder _decoder = new EtwDecoder();
        private List<Dictionary<int, string>> _eventNameDictionary = new List<Dictionary<int, string>>();
        private List<EtwProvider> _providers = new List<EtwProvider>();
        private List<EtwDataEventListener> _dataListeners = new List<EtwDataEventListener>();

        private EtwDecoder GlobalEtwDecoder
        {
            get { return _decoder; }
            set
            { 
                _decoder = value;
                var itemConverter = this.Resources["EventConverter"] as EtwDataEventToEtwDataEventItemConverter;
                itemConverter.Decoder = value;
            }
        }

        private void OnToggleTimestampCommand()
        {
            var itemConverter = this.Resources["EventConverter"] as EtwDataEventToEtwDataEventItemConverter;
            itemConverter.ShowTimestamp = true ^ itemConverter.ShowTimestamp;
            RebuildTree();
        }

        public MainWindow()
        {
            // Assign Commands before InitializeComponent
            // Otherwise the bindings don't work
            LoadCommand = new NodeItem<ICommand>(new DelegateCommand((param) => OnLoadDataCommand()));
            SaveCommand = new NodeItem<ICommand>(new DelegateCommand((param) => OnSaveDataCommand()));

            string help = "Please refer to the article on codeproject.com";
            HelpCommand = new NodeItem<ICommand>(new DelegateCommand((param) => MessageBox.Show(help, "Help")));


            string about = @"Etw Data Viewer

A prototype app for viewing custom made manifest based etw events.
The idea was to evaluate the possibilities to make
a hierarchical tree based on the order and context of the events.
Adding data analysis, searching, and data drill down
was also part of the initial intent to give meaning to raw data.

The analysis is custom made for the providers of the demo app.
Other providers will show up in app, but the tree will be flat,
because the hierarchical context is missing.

In the future one could perhaps use a system with plug-ins
for the analysis, but this has not yet been implemented.
Until then, feel free to replace the analysis with your own.

Mattias Högström
";
            AboutCommand = new NodeItem<ICommand>(new DelegateCommand((param) => MessageBox.Show(about, "About")));

            RebuildTreeCommand = new NodeItem<ICommand>(new DelegateCommand((param) => RebuildTree()));
            ClearCommand = new NodeItem<ICommand>(new DelegateCommand((param) => OnClearDataCommand()));
            LoadManifestCommand = new NodeItem<ICommand>(new DelegateCommand((param) => OnLoadManifestCommand()));
            StartCommand = new NodeItem<ICommand>(new DelegateCommand((param) => OnStartCommand()));
            StopCommand = new NodeItem<ICommand>(new DelegateCommand((param) => OnStopCommand()));
            RunDemoCommand = new NodeItem<ICommand>(new DelegateCommand((param) => OnRunDemoCommand()));
            ToggleTimestampCommand = new NodeItem<ICommand>(new DelegateCommand((param) => OnToggleTimestampCommand()));

            _sqlCommands.Add(new NodeItem<string>("SELECT"));
            _sqlCommands.Add(new NodeItem<string>("INSERT"));
            _sqlCommands.Add(new NodeItem<string>("UPDATE"));
            _sqlCommands.Add(new NodeItem<string>("DELETE"));


            InitializeComponent();

            _refreshTimer.Interval = new TimeSpan(0, 0, 0, 0, Convert.ToInt32(SliderInterval.Value));
            _refreshTimer.Tick += RefreshTimer_Tick;
            _refreshTimer.Stop();

            UpdateMenuStatus();

            this.Closing += MainWindow_Closing;
            this.Closed += (sender, args) => System.Threading.Thread.Sleep(4000); ;
        }

        async void MainWindow_Closing(object sender, CancelEventArgs e)
        {
            await _workerQueue.QueueTask(() =>
            {
                try
                {
                    OnStopCommand();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Trace.WriteLine(ex.Message);
                }
            });
            GC.Collect();
        }

        void RunDemo()
        {
            OnStopCommand();
            var assembly = System.Reflection.Assembly.GetExecutingAssembly();
            var stream = assembly.GetManifestResourceStream("EtwDataViewer.EtwProducerSampleAppTracing.man");
            LoadManifestFromStream(stream);
            OnStartCommand();
        }

        void OnRunDemoCommand()
        {
            _workerQueue.QueueTask(() => RunDemo());
        }

        void OnStartCommand()
        {
            if (CanStart)
            {
                _dataListeners.ForEach(n => n.Start());
                _refreshTimer.Start();
                UpdateMenuStatus();
            }
        }

        void OnStopCommand()
        {
            if (IsRunning)
            {
                _refreshTimer.Stop();
                _dataListeners.ForEach(n => n.Stop());
                UpdateMenuStatus();
            }
        }

        void RefreshTimer_Tick(object sender, EventArgs e)
        {
            _refreshTimer.Stop();
            _workerQueue.QueueTask(() =>
            {
                try
                {
                    CollectAndProcessEvents();
                    UpdateWmi();
                }
                catch (Exception)
                {
                    // ignore
                }
                finally
                {
                    _refreshTimer.Start();                
                }
            });
        }

        List<EtwDataEvent> CollectNewEvents()
        {
            var newEvents = new List<EtwDataEvent>();
            _dataListeners.ForEach(listener => newEvents.AddRange(listener.FlushLog()));
            return newEvents;  
        }

        List<EtwDataEvent> SortEvents(List<EtwDataEvent> newEvents)
        {
            if (newEvents.Count != 0)
            {
                newEvents.Sort(); // implements IComparable
            }
            return newEvents;
        }

        List<EtwDataEvent> PreprocessEvents(List<EtwDataEvent> newEvents)
        {
            // This _demoAnalyzer is application specific
            // The search tags depends on the manifest

            newEvents = _demoAnalyzer.PreprocessEvents(newEvents);

            var tableList = _demoAnalyzer.ReferencedTableNames;

            Dispatcher.Invoke(() =>
            {
                tableList.Distinct().Where(n => _tableNames.FirstOrDefault(str => str.Content == n) == null).ToList().ForEach(n => _tableNames.Add(new NodeItem<string>(n)));
                newEvents.Select(n => n.Header.ProcessId).Distinct().Where(n => _wmiDataPerProcess.Count(p => p.Content.IDProcess == n) == 0).ToList().ForEach(w => AddProcess(w, true));
            });

            return newEvents;
        }


        private List<EtwDataEventItem> PostProcessEvents(List<EtwDataEvent> list)
        {
            return _demoAnalyzer.BuildTree(list);
        }

       
        private void CollectAndProcessEvents()
        {

            var newEvents = CollectNewEvents();
            var sortedEvents = SortEvents(newEvents);
            
            // provider specific
            // Added just for demo purposes
            var preprocessedEvents = PreprocessEvents(sortedEvents);
    
            // Add new events to full log
            _allEvents.AddRange(preprocessedEvents);
            
            BuildTree(preprocessedEvents);
        }

        void BuildTree(List<EtwDataEvent> etwEvents, bool forceUpdate = false)
        {
            // Remove events from processes that are unselected
            var filteredList0 = ApplyProcessIdFilter(etwEvents);

            // Remove events according to the event Id list
            var filteredList1 = ApplyEventFilter(filteredList0);

            // Remove events (SELECT/UPDATE/INSERT...)
            var filteredList2 = ApplySqlFilter(filteredList1);

            // Remove events based on table name
            var filteredList3 = ApplySqlTableFilter(filteredList2);

            // Build a hierarchial tree depending on context
            var visualTree = PostProcessEvents(filteredList3);

            Dispatcher.Invoke(() =>
            {
                if (forceUpdate) _filteredEvents.Clear();
                visualTree.ForEach(n => _filteredEvents.Add(n));
            });
        }

        void LoadManifestFromStream(System.IO.Stream inputStream)
        {
            GlobalEtwDecoder = new EtwDecoder(inputStream);
            _providers = GlobalEtwDecoder.Providers();
            var resourceFileNames = new List<string>();
            _dataListeners.ForEach(listener => listener.Stop());
            _dataListeners.Clear();
            List<EtwEventItem> eventTypeList = new List<EtwEventItem>();
            foreach (var provider in _providers)
            {
                string logName = provider.Name.ToLowerInvariant();
                Guid sessionId = Guid.NewGuid();
                _dataListeners.Add(new EtwDataEventListener(logName, provider.ProviderId, sessionId));
                var treeNode = new EtwEventItem(provider.Name, provider.ProviderId);
                var eventTypes = GlobalEtwDecoder.DecodeEvents(provider.ProviderId);
                eventTypes.ToList().ForEach(n => treeNode.Children.Add(new EtwEventItem(n.Value, provider.ProviderId, n.Key)));
                _eventNameDictionary.Add(eventTypes);
                eventTypeList.Add(treeNode);
                var filename = new System.IO.FileInfo(provider.ResourceFilename);
                string shortFilename = filename.Name.ToLowerInvariant();
                resourceFileNames.Add(shortFilename);
            }
            _providerFilenames = resourceFileNames.Distinct().ToList();
            
            Dispatcher.Invoke(() =>
            {
                _eventTypeNames.Clear();
                eventTypeList.ForEach(_eventTypeNames.Add);
                UpdateMenuStatus();
            });
        }

        void OnLoadManifestCommand()
        {
            _refreshTimer.Stop();
            var dialog = new Microsoft.Win32.OpenFileDialog();
            dialog.CheckFileExists = true;
            dialog.Filter = "manifest (*.man)|*.man";
            var result = dialog.ShowDialog();
            if (result.Value)
            {
                using (var fileStream = dialog.OpenFile())
                {
                    LoadManifestFromStream(fileStream);                    
                }
            }
        }

        void RebuildTree()
        {
            BuildTree(_allEvents, true);
        }

        private void ClearWindows()
        {
            Dispatcher.Invoke(() =>
            {
                _allEvents.Clear();
                _filteredEvents.Clear();
                _foundTableNames.Clear();
                _tableNames.Clear();
                _wmiDataPerProcess.Clear();
            });
            UpdateWmi();
        }


        void ClearData()
        {
            _dataListeners.ForEach(n => n.FlushLog());
            ClearWindows();
            RebuildTree();
        }

        void OnClearDataCommand()
        {
            _workerQueue.QueueTask(() => ClearData());
        }

        public string _fileFilter = "vbus etw log file (*.vbl)|*.vbl";

        void OnLoadDataCommand()
        {
            var dialog = new Microsoft.Win32.OpenFileDialog();
            dialog.CheckFileExists = true;
            dialog.Filter = _fileFilter;
            var result = dialog.ShowDialog();
            if (result.Value)
            {
                ClearData();
                var list = new List<EtwDataEvent>();
                var tableList = new List<string>();

                using (var fileStream = dialog.OpenFile())
                {
                    var ser = new DataContractSerializer(typeof(List<EtwDataEvent>));
                    list = (List<EtwDataEvent>)ser.ReadObject(fileStream);

                    list = _demoAnalyzer.PreprocessEvents(list);
                    tableList = _demoAnalyzer.ReferencedTableNames;
                }
                Dispatcher.Invoke(() =>
                {
                    _foundTableNames.Clear();
                    tableList.ForEach(n => _foundTableNames.Add(new NodeItem<string>(n)));
                    _wmiDataPerProcess.Clear();
                    _wmiDataGlobal.Clear();
                    list.Select(n => n.Header.ProcessId).Distinct().ToList().ForEach(n => AddProcess(n));
                });
                _allEvents.AddRange(list);
                RebuildTree();
            }
        }

        void AddProcess(int pId, bool loadRuntimeInfo = false)
        {
            string productVersion = string.Empty;
            if (loadRuntimeInfo)
            {
                productVersion = GetFileDetails(pId);
            }
            _wmiDataPerProcess.Add(new NodeItem<WmiDataType>(new WmiDataType() { IDProcess = (uint)pId, ProductVersion = productVersion }));
        }

        public static string GetFileDetails(int pId)
        {
            var process = System.Diagnostics.Process.GetProcessById(Convert.ToInt32(pId));
            var fileName = process.Modules[0].FileName;

            var fileInfo = new System.IO.FileInfo(fileName);


            List<string> arrHeaders = new List<string>();

            var shell = new Shell32.ShellClass();
            var rFolder = shell.NameSpace(fileInfo.DirectoryName);
            var rFiles = rFolder.ParseName(fileInfo.Name);
            string productVersion = rFolder.GetDetailsOf(rFiles, 271);
            string productName = rFolder.GetDetailsOf(rFiles, 270);
            //for (int i = 0; i < short.MaxValue; i++)
            //{
            //    string value = rFolder.GetDetailsOf(rFiles, i).Trim();
            //    arrHeaders.Add(value);
            //}
            return productVersion;
        }

        void OnSaveDataCommand()
        {
            var dialog = new Microsoft.Win32.SaveFileDialog { Filter = _fileFilter };
            var result = dialog.ShowDialog();
            if (result.Value)
            {
                using (var fileStream = dialog.OpenFile())
                {
                    var ser = new DataContractSerializer(typeof(List<EtwDataEvent>));
                    //Remove All object that do not implement ISerializable
                    _demoAnalyzer.PrepareForSave(_allEvents);
                    ser.WriteObject(fileStream, _allEvents);
                    //Restore the objects previously removed
                    _allEvents = _demoAnalyzer.PreprocessEvents(_allEvents);                    
                }
            }
        }

        private void OnSliderIntervalValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (_refreshTimer != null)
            {
                var val = Convert.ToInt32(SliderInterval.Value);
                _refreshTimer.Interval = new TimeSpan(0, 0, 0, 0, val);
            }
        }


        private List<EtwDataEvent> ApplyProcessIdFilter(List<EtwDataEvent> list)
        {
            var pIdList = _wmiDataPerProcess.Where(n => n.IsEnabled).Select(n => n.Content.IDProcess).ToList();
            var restEvents = (from newEvent in list
                              from pId in pIdList
                              where newEvent.Header.ProcessId == pId
                              select newEvent).ToList();
            return restEvents;
        }

        private List<EtwDataEvent> ApplySqlTableFilter(List<EtwDataEvent> list)
        {
            var excludedTables = _tableNames.Where(n => n.IsEnabled == false).Select(n => n.Content).ToList();
            if (excludedTables.Count == 0)
                return list;

            var remaining = list.Where(n => FilterTableNames(n, excludedTables)).ToList();
            return remaining;

        }

        private bool FilterTableNames(EtwDataEvent eventArrivedEvent, List<string> excludedTables)
        {
            if (excludedTables.Count == 0)
                return true;
            if (!eventArrivedEvent.Properties.ContainsKey("parsedQuery"))
                return true;
            var parseTree = eventArrivedEvent.Properties["parsedQuery"] as Irony.Parsing.ParseTree;
            if (parseTree.Root != null)
            {
                if (parseTree.Root.ChildNodes != null)
                {
                    var sqlQuery = parseTree.Root.ChildNodes.FirstOrDefault();
                    if (sqlQuery != null)
                    {
                        var sqlName = sqlQuery.ChildNodes.First().Term.Name;
                        if (sqlName == "SELECT")
                        {
                            string tableName = sqlQuery.ChildNodes[4].ChildNodes[1].ChildNodes[0].ChildNodes[0].Token.Text;
                            return !excludedTables.Contains(tableName);
                        }
                        else if (sqlName == "UPDATE")
                        {
                            string tableName = sqlQuery.ChildNodes[1].ChildNodes[0].Token.Text;
                            return !excludedTables.Contains(tableName);
                        }
                        else if (sqlName == "DELETE")
                        {
                            string tableName = sqlQuery.ChildNodes[2].ChildNodes[0].Token.Text;
                            return !excludedTables.Contains(tableName);
                        }
                        else if (sqlName == "INSERT")
                        {
                            string tableName = sqlQuery.ChildNodes[2].ChildNodes[0].Token.Text;
                            return !excludedTables.Contains(tableName);
                        }
                        return false;
                    }
                }
            }
            return false;
        }

        private bool FilterSqlQueries(EtwDataEvent eventArrivedEvent, List<string> excludedSqlCommands)
        {
            if (excludedSqlCommands.Count == 0)
                return true;
            if (!eventArrivedEvent.Properties.ContainsKey("parsedQuery"))
                return true;

            var parseTree = eventArrivedEvent.Properties["parsedQuery"] as Irony.Parsing.ParseTree;
            if (parseTree.Root != null)
            {
                if (parseTree.Root.ChildNodes != null)
                {
                    var sqlQuery = parseTree.Root.ChildNodes.FirstOrDefault();
                    if (sqlQuery != null)
                    {
                        var sqlName = sqlQuery.ChildNodes.First().Term.Name;
                        return !excludedSqlCommands.Contains(sqlName);
                    }
                }
            }
            return false;
        }

        private List<EtwDataEvent> ApplySqlFilter(List<EtwDataEvent> list)
        {
            var excludedSqlCommands = _sqlCommands.Where(n => n.IsEnabled == false).Select(n => n.Content).ToList();
            if (excludedSqlCommands.Count == 0)
                return list;

            var remaining = list.Where(n => FilterSqlQueries(n, excludedSqlCommands)).ToList();
            return remaining;
        }

        private List<EtwDataEvent> ApplyEventFilter(List<EtwDataEvent> list)
        {
            var filter = GetNodeFilter();
            var filteredList = list.Where(n => filter.Find(a => a.EventId == n.Header.EventId && a.ProviderId == n.Header.ProviderId) != null).ToList();
            return filteredList;
        }

        private void OnCheckedToggled(object sender, RoutedEventArgs e)
        {
            _workerQueue.QueueTask(() =>
            {
                var cb = sender as CheckBox;
                if (cb == null)
                    return;
                Dispatcher.Invoke(() =>
                {
                    bool isChecked = (cb.IsChecked == true);
                    var content = cb.Content as string;
                    if (string.IsNullOrEmpty(content))
                        return;

                    var nodes = FindNodesToUpdate(content).ToList();

                    foreach (var vBusEventTypeNode in nodes)
                    {
                        vBusEventTypeNode.IsActive = isChecked;
                    }
                });

                RebuildTree();
            });
        }

        private IEnumerable<EtwEventItem> FindNodesToUpdate(string eventName)
        {
            foreach (var vBusEventTypeNode in EventTypeNames)
            {
                if (vBusEventTypeNode.EventName == eventName)
                {
                    return vBusEventTypeNode.Children;
                }
                else
                {
                    var node = vBusEventTypeNode.Children.FirstOrDefault(n => n.EventName == eventName);
                    if (node == null)
                        continue;
                    return new[] { node };
                }
            }
            return new EtwEventItem[] { };
        }

        private List<EtwEventItem> GetNodeFilter()
        {
            var list = new List<EtwEventItem>();

            foreach (var vBusEventTypeNode in _eventTypeNames)
            {
                var showEvents = vBusEventTypeNode.Children.Where(n => n.IsActive).ToList();
                list.AddRange(showEvents);
            }
            return list;
        }

        private void Ygrdrasil_OnSelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
           
            var target = e.NewValue as EtwDataEventItem;
            if (target == null)
            {
                TextBoxSelectedEvent.Text = string.Empty;
                return;
            }

            TextBoxSelectedEvent.Text = _demoAnalyzer.GetEtwDataDetails(target);
        }
    }
}
