﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Samples.Eventing;

namespace EtwConsumer
{
    public class EtwDataEventListener : IDisposable
    {
        private IEventTraceWatcher _watcher;
        private List<EventArrivedEventArgs> _providerEvents = new List<EventArrivedEventArgs>();
        private readonly List<EventArrivedEventArgs> _errors = new List<EventArrivedEventArgs>();

        public IEventTraceWatcher LogWatcher
        {
            get { return _watcher; }
        }

        public static IEventTraceWatcherFactory _eventTraceWatcherFactory = new EventTraceWatcherFactory();

        public EtwDataEventListener(string logname, Guid providerId, Guid sessionId)
        {
            _watcher = _eventTraceWatcherFactory.Create(logname, providerId, sessionId);
            _watcher.EventArrived += delegate(object sender, EventArrivedEventArgs e)
            {

                if (e.Error != null)
                {

                    _errors.Add(e);
                    _watcher.Stop();
                }
                lock (_providerEvents)
                {
                    _providerEvents.Add(e);
                }
            };

        }

        public bool IsRunning
        {
            get { return _watcher.IsEnabled; }
        }
        
        public void Start()
        {
            _watcher.Start();
        }

        public void Stop()
        {
            _watcher.Stop();
        }

        public void Dispose()
        {
            Stop();
            _watcher.Dispose();
        }

        public List<EtwDataEvent> FlushLog()
        {
            lock (_providerEvents)
            {
                var currentEvents = _providerEvents;
                _providerEvents = new List<EventArrivedEventArgs>();
                var newEvents = currentEvents.Select(e => new EtwDataEvent(e.Header, e.Properties)).ToList();
                return newEvents;
            }
        }

        public List<EtwDataEvent> ProcessNewEvents()
        {
            var newEvents = FlushLog();
            if (ProcessEventDelegate == null)
                return newEvents;
            newEvents.ForEach(n => ProcessEventDelegate(n));
            return newEvents;
        }

        public Func<EtwDataEvent, bool> ProcessEventDelegate;
    }
}
