﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;
using Samples.Eventing;



namespace EtwConsumer
{
    public class EtwDecoder
    {
        //private StreamReader _textStreamReader;
        //private XDocument _xdocument;
        private IEnumerable<XElement> _elements;

        public bool IsValid { get; protected set; }
        public EtwDecoder(Stream stream)
        {
            var textStreamReader = new StreamReader(stream);
            var xdocument = XDocument.Load(textStreamReader);
            _elements = xdocument.Root.Elements();
            IsValid = true;
        }

        public EtwDecoder()
        {
            _elements = new List<XElement>();
        }

        public List<EtwProvider> Providers()
        {
            var result = new List<EtwProvider>();
            if (_elements.Count() == 0)
                return result;
            var instrumentationNode = _elements.FirstOrDefault(e => e.Name.LocalName == "instrumentation");
            var eventsNode = instrumentationNode.Elements().FirstOrDefault(e => e.Name.LocalName == "events");

            var providers = eventsNode.Elements().Where(e => e.Name.LocalName == "provider").ToList();
            providers.ForEach(n =>
                      {
                          var guid = new Guid(n.Attribute("guid").Value);
                          var name = n.Attribute("name").Value;
                          var symbol = n.Attribute("symbol").Value;
                          var resourceFilename = n.Attribute("resourceFileName").Value;
                          var messageFilename = n.Attribute("messageFileName").Value;
                          result.Add(new EtwProvider(guid, name, symbol, resourceFilename, messageFilename));
                      });
            return result;
        }

        public Dictionary<int, string> DecodeEvents(Guid guid)
        {
            var dic = new Dictionary<int, string>();
            var instrumentationNode = _elements.FirstOrDefault(e => e.Name.LocalName == "instrumentation");
            var eventsNode = instrumentationNode.Elements().FirstOrDefault(e => e.Name.LocalName == "events");
            string str = guid.ToString("B").ToUpperInvariant();
            var providers = eventsNode.Elements().Where(e => e.Name.LocalName == "provider");
            var provider = providers.FirstOrDefault(e => e.Attribute("guid").Value == str);

            var eventsNode2 = provider.Elements().FirstOrDefault(e => e.Name.LocalName == "events");
            eventsNode2.Elements().ToList().ForEach(e =>
                {
                    int key = int.Parse(e.Attribute("value").Value);
                    string val = e.Attribute("symbol").Value;
                    dic.Add(key, val);
                });

            return dic;
        }
    }
}
