﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

using Samples.Eventing;
using Samples.Eventing.Interop;

namespace EtwConsumer
{
    [DataContract(Namespace="")]
    public class EtwDataEvent : IEtwDataEvent, IComparable<EtwDataEvent>
    {
        public EtwDataEvent()
        {
        }

        internal EtwDataEvent(EventHeader header, PropertyBag properties)
        {
            _header = new EtwEventHeader(header);
            _properties = new EtwPropertyBag(properties);
        }

        [DataMember] private EtwPropertyBag _properties;
        [DataMember] private EtwEventHeader _header;
    
        public EtwPropertyBag Properties
        {
            get { return _properties; }
        }

        public EtwEventHeader Header
        {
            get { return _header; }
        }

        public Guid ProviderId
        {
            get { return _header.ProviderId; }
        }

        public int EventId
        {
            get { return _header.EventId; }
        }

        public int CompareTo(EtwDataEvent other)
        {
            return this.Header.TimeStamp.CompareTo(other.Header.TimeStamp);
        }
    }
}

