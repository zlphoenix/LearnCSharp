﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Samples.Eventing.Interop;

namespace EtwConsumer.Tests
{
    [TestClass]
    public class EtwDataListenerTest
    {
        [TestInitialize]
        public void Setup()
        {
            // Prevents the actual EventTraceWatcher to run
            // Events must be sent manually via the SendEvent function
            EtwDataEventListener._eventTraceWatcherFactory = new EventTraceWatcherFactoryFake();
        }

        [TestMethod]
        public void Create_NoExceptions()
        {
            var listener = new EtwDataEventListener("test1", new Guid(), new Guid());
        }

        [TestMethod]
        public void ProcessNewEvents_NoEvents_ReturnsEmptyList()
        {
            // Arrange
            var listener = new EtwDataEventListener("test1", new Guid(), new Guid());
            
            // Act
            listener.Start();
            var eventList = listener.ProcessNewEvents();
            listener.Stop();

            // Assert        
            Assert.AreEqual(0, eventList.Count);
           
        }

        [TestMethod]
        public void ProcessNewEvents_Send1Event_Returns1Event_1()
        {
            // Arrange
            Guid provider = new Guid("{33FF0139-C715-4C4A-8793-99AAD1663FDB}");
            Guid session = new Guid("{CF3C699F-9E4C-4A13-B2B8-D5DE5AB701EF}");

            var listener = new EtwDataEventListener("test1", provider, session);
            
            // Act
            listener.Start();
            var newEvent = CreateDefaultCommandEvent(provider, 1, "A");
            listener.LogWatcher.SendEvent(newEvent);

            var eventList = listener.ProcessNewEvents();
            listener.Stop();

            // Assert
            Assert.AreEqual(1, eventList.Count);
            
        }        

        [TestMethod]
        void ProcessNewEvents_Send1Event_Returns1Event_2()
        {
            // Arrange
            var providers = LoadTestProviders();            
            var uniqueSessionId = Guid.NewGuid();
            var provider = providers.First();

            // Act
            var listener = new EtwDataEventListener("test1", provider.ProviderId, uniqueSessionId);
            listener.Start();
            var newEvent = CreateDefaultCommandEvent(provider.ProviderId, 1, "A");
            listener.LogWatcher.SendEvent(newEvent);

            var eventList = listener.ProcessNewEvents();
            listener.Stop();

            // Assert
            Assert.AreEqual(1, eventList.Count);            
        }

        List<EtwProvider> LoadTestProviders()
        {
            var assembly = System.Reflection.Assembly.GetExecutingAssembly();
            var stream = assembly.GetManifestResourceStream("EtwConsumer.Tests.EtwProducerSampleAppTracing.man");
            var decoder = new EtwDecoder(stream);
            var providers = decoder.Providers();
            return providers;
        }

        Samples.Eventing.EventArrivedEventArgs CreateDefaultCommandEvent(Guid provider, int eventId, string commandName)
        {
            var header = new Samples.Eventing.Interop.EventHeader()
            {
                ActivityId = provider,
                TimeStamp = 1,
                ProcessId = 1234,
                EventDescriptor = new Samples.Eventing.Interop.EtwEventDescriptor()
                {
                    Channel = 1,
                    Id = (ushort)eventId,
                    Keyword = 1,
                    Level = 1,
                    Opcode = 1,
                    Task = 1,
                    Version = 1
                }
            };
            var props = new Samples.Eventing.PropertyBag
                 {
                    {"commandName", commandName}
                 };

            var fakeEvent = new Samples.Eventing.EventArrivedEventArgs(1, header, props);
            return fakeEvent;
        }
    }
}
