﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EtwConsumer.Tests
{
    [TestClass]
    public class EtwDecoderTest
    {
        [TestMethod]
        public void Create_WithoutManifest_NoExceptions()
        {
            var decoder = new EtwDecoder();
        }

        [TestMethod]
        public void Create_WithoutManifest_Providers_ReturnsEmptyList()
        {
            var decoder = new EtwDecoder();
            Assert.AreEqual(0, decoder.Providers().Count);
        }

        [TestMethod]
        public void Create_WithoutManifest_IsValid_ReturnsFalse()
        {
            var decoder = new EtwDecoder();
            Assert.AreEqual(false, decoder.IsValid);
        }

        [TestMethod]
        public void Create_WithManifest_NoExceptions()
        {
            var assembly = System.Reflection.Assembly.GetExecutingAssembly();
            var stream = assembly.GetManifestResourceStream("EtwConsumer.Tests.EtwProducerSampleAppTracing.man");
            var decoder = new EtwDecoder(stream);
        }

        [TestMethod]
        public void Create_WithManifest_IsValid_ReturnsTrue()
        {
            var assembly = System.Reflection.Assembly.GetExecutingAssembly();
            var stream = assembly.GetManifestResourceStream("EtwConsumer.Tests.EtwProducerSampleAppTracing.man");
            var decoder = new EtwDecoder(stream);
            Assert.AreEqual(true, decoder.IsValid);
        }

        [TestMethod]
        public void Create_WithManifest_Providers_CountReturns2Elements()
        {
            var assembly = System.Reflection.Assembly.GetExecutingAssembly();
            var stream = assembly.GetManifestResourceStream("EtwConsumer.Tests.EtwProducerSampleAppTracing.man");
            var decoder = new EtwDecoder(stream);
            var providers = decoder.Providers();
            Assert.AreEqual(2, providers.Count);
        }

        [TestMethod]
        public void Create_WithManifest_Providers_ReturnsAValidElement()
        {
            var assembly = System.Reflection.Assembly.GetExecutingAssembly();
            var stream = assembly.GetManifestResourceStream("EtwConsumer.Tests.EtwProducerSampleAppTracing.man");
            var decoder = new EtwDecoder(stream);
            var providers = decoder.Providers();

            var provider = providers.First();
            var resourceFilename = new System.IO.FileInfo(provider.ResourceFilename).Name.ToLowerInvariant();
            var messageFilename = new System.IO.FileInfo(provider.MessageFilename).Name.ToLowerInvariant();
            
            Assert.AreEqual("EtwProducerSampleAppCommandProvider", provider.Name);
            Assert.AreEqual("EtwProducerSampleAppCommandTraceProvider", provider.Symbol);
            Assert.AreEqual("99BB72C0-0F4B-4178-98FB-55B624D87357", provider.ProviderId.ToString().ToUpper());
            Assert.AreEqual("etwproducersampleapp.exe", resourceFilename);
            Assert.AreEqual("etwproducersampleapp.exe", messageFilename);            
        }
    }
}
