﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Samples.Eventing;

using EtwConsumer;

namespace EtwConsumer.Tests
{
    public class EventTraceWatcherFactoryFake : IEventTraceWatcherFactory
    {
        public IEventTraceWatcher Create(string loggerName, Guid eventProviderId, Guid sessionId)
        {
            return new EventTraceWatcherFake(loggerName, eventProviderId, sessionId);
        }
    }
}
