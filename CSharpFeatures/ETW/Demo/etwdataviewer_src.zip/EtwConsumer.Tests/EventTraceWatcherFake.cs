﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Samples.Eventing;

namespace EtwConsumer.Tests
{
    public class EventTraceWatcherFake : IEventTraceWatcher
    {
        public EventTraceWatcherFake(string loggerName, Guid eventProviderId, Guid sessionId)
        {

        }

        public bool IsEnabled { get { return true; } }

        public void Dispose()
        {

        }

        public void Start()
        {

        }

        public void Stop()
        {

        }

        public event EventHandler<EventArrivedEventArgs> EventArrived;

        public void SendEvent(EventArrivedEventArgs fakeEvent)
        {
            EventHandler<EventArrivedEventArgs> eventArrived = this.EventArrived;
            if (eventArrived != null)
            {
                eventArrived(this, fakeEvent);
            }
        }
    }
}