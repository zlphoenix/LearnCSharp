﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

using EtwDataViewer;
using EtwProducerSampleApp.EtwTracing;

namespace EtwProducerSampleApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Random _random = new Random();
        public ICommand DoCommand { get; protected set; }

        public MainWindow()
        {
            DoCommand = new DelegateCommand((param) =>
                {
                    var commandName = param as string;
                    EtwProducerSampleAppCommandTraceProvider.EventWriteFunctionEntryGeneralCommand(commandName);
                    Thread.Sleep(50);
                    Thread.SpinWait(10000);
                    RunGeneralCommand();
                    textBoxLog.Text += param + Environment.NewLine;
                    Thread.Sleep(50);
                    EtwProducerSampleAppCommandTraceProvider.EventWriteFunctionExitGeneralCommand(commandName);
                });
            InitializeComponent();
        }        

        private void RunGeneralCommand()
        {
            FetchData();
            UpdateData();
        }

        #region FakeEvents
        private void UpdateData()
        {
            EtwProducerSampleAppSqlTraceProvider.EventWriteFunctionLogQuery("Writer", _random.Next(1000), "UPDATE Order SET SupplierNo = 1234");
        }

        private static void FetchData()
        {
            EtwProducerSampleAppSqlTraceProvider.EventWriteFunctionLogQuery("Reader", 1001, "SELECT Id, SupplierNo, CustomerNo From Order");
            EtwProducerSampleAppSqlTraceProvider.EventWriteFunctionLogQuery("Reader", 1002, "SELECT Id, Quantity From Orderline");
        }

        #endregion
    }
}
