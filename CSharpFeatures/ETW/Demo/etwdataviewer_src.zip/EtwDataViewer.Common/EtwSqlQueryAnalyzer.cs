﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EtwDataViewer.Common
{
    public static class EtwSqlQueryAnalyzer
    {
        static Irony.Samples.SQL.SqlGrammar _sqlGrammar = new Irony.Samples.SQL.SqlGrammar();
        static Irony.Parsing.LanguageData _languageData = new Irony.Parsing.LanguageData(_sqlGrammar);
        static Irony.Parsing.Parser _parser = new Irony.Parsing.Parser(_languageData);

        public static Irony.Parsing.ParseTree Parse(string query, bool tryRecover = true)
        {
            var parseTree = _parser.Parse(query);
            if (parseTree.Root != null)
            {
                return parseTree;
            }
            else if (tryRecover)
            {
                string correctedString = query.Replace("?", "NULL");
                return Parse(correctedString, false);
            }
            else
            {
                // returns with failures
                return parseTree;
            }
        }
    }
}
