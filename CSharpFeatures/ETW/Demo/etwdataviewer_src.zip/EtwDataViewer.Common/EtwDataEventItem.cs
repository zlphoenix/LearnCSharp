﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

using EtwConsumer;

namespace EtwDataViewer.Common
{
    public class EtwDataEventItem : INotifyPropertyChanged
    {
        private readonly EtwDataEvent _event;
        private bool _isActive;

        public bool IsEnabled
        {
            get { return _isActive; }
            set { SetProperty(ref _isActive, value); }
        }

        public Guid ProviderId { get { return _event.Header.ProviderId; } }
        public int EventId { get { return _event.Header.EventId; } }


        private readonly ObservableCollection<EtwDataEventItem> _children;
        public EtwDataEvent Content { get { return _event; } }
        public ObservableCollection<EtwDataEventItem> Children { get { return _children; } }
        public EtwDataEventItem(EtwDataEvent root)
        {
            IsEnabled = true;
            _event = root;
            _children = new ObservableCollection<EtwDataEventItem>();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void SetProperty<T>(ref T field, T value, [CallerMemberName] string name = "")
        {
            if (!EqualityComparer<T>.Default.Equals(field, value))
            {
                field = value;
                var handler = PropertyChanged;
                if (handler != null)
                {
                    handler(this, new PropertyChangedEventArgs(name));
                }
            }
        }
    } 
}
