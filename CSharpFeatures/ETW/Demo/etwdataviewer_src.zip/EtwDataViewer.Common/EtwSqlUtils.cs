﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EtwDataViewer.Common
{
    public class EtwSqlUtils
    {
        public static string ExtractTableName(Irony.Parsing.ParseTree parseTree)
        {
            if (parseTree == null)
                return string.Empty;

            if (parseTree.Root == null)
                return string.Empty;

            if (parseTree.Root.ChildNodes == null)
                return string.Empty;


            var sqlQuery = parseTree.Root.ChildNodes.FirstOrDefault();
            if (sqlQuery == null)
                return string.Empty;


            var sqlName = sqlQuery.ChildNodes.First().Term.Name;
            if (sqlName == "SELECT")
            {
                string tableName = sqlQuery.ChildNodes[4].ChildNodes[1].ChildNodes[0].ChildNodes[0].Token.Text;
                return tableName;
            }
            else if (sqlName == "UPDATE")
            {
                string tableName = sqlQuery.ChildNodes[1].ChildNodes[0].Token.Text;
                return tableName;
            }
            else if (sqlName == "DELETE")
            {
                string tableName = sqlQuery.ChildNodes[2].ChildNodes[0].Token.Text;
                return tableName;
            }
            else if (sqlName == "INSERT")
            {
                string tableName = sqlQuery.ChildNodes[2].ChildNodes[0].Token.Text;
                return tableName;
            }
            return string.Empty;
        }


    }
}
