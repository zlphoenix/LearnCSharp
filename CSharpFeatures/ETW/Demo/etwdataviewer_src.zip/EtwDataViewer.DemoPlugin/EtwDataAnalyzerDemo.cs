﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EtwConsumer;
using EtwDataViewer.Common;
using EtwDataViewer.Plugin;

namespace EtwDataViewer.DemoPlugin
{
    public class EtwDataAnalyzerDemo : IEtwDataAnalyzer
    {
        static Guid _demoCommandProvider = new Guid("{99BB72C0-0F4B-4178-98FB-55B624D87357}");
        static Guid _demoSqlProvider = new Guid("{47E32258-70FF-4962-98FD-FC98B6E8DDBC}");

        public List<Guid> Providers { get; protected set; }

        public List<string> _referencedTableNames = new List<string>();

        public EtwDataAnalyzerDemo()
        {
            Providers = new List<Guid>();
            Providers.Add(_demoCommandProvider);
            Providers.Add(_demoSqlProvider);
        }

        public List<EtwDataEvent> PreprocessEvents(List<EtwDataEvent> newEvents)
        {
            var tableNames = HandleSqlQueries(newEvents);
            _referencedTableNames.AddRange(tableNames);
            _referencedTableNames = _referencedTableNames.Distinct().ToList();
            return newEvents;
        }
        
        public List<string> ReferencedTableNames
        {
            get { return _referencedTableNames; }
        }

        public void PrepareForSave(List<EtwDataEvent> allEvents)
        {
            // Removing objects that do not implement ISerializable
            allEvents.ForEach(n =>
            {
                if (n.Properties.ContainsKey("parsedQuery"))
                {
                    n.Properties.Remove("parsedQuery");
                }
            });
        }

        private List<string> HandleSqlQueries(List<EtwDataEvent> newEvents)
        {
            var tableList = new List<string>();
            newEvents.ForEach(n =>
            {
                if (n.Properties.ContainsKey("query"))
                {
                    var query = n.Properties["query"] as string;
                    var parseTree = EtwSqlQueryAnalyzer.Parse(query);
                    var tableName = EtwSqlUtils.ExtractTableName(parseTree);

                    if (!string.IsNullOrEmpty(tableName))
                    {
                        tableList.Add(tableName);
                    }
                    n.Properties["parsedQuery"] = parseTree;
                }
            });
            return tableList;
        }

        public string GetEtwDataDetails(EtwDataEventItem selectedEvent)
        {
            var eventData = selectedEvent.Content;
            var sb = new System.Text.StringBuilder();

            if (_demoSqlProvider == eventData.Header.ProviderId)
            {
                if (eventData.Properties.ContainsKey("query"))
                {
                    string sqlQuery = eventData.Properties["query"] as string;
                    sb.AppendLine(sqlQuery);
                }
            }
            else if (_demoCommandProvider == eventData.Header.ProviderId)
            {
                selectedEvent.Children.ToList().ForEach(n =>
                {
                    var subEventData = n.Content;
                    if (subEventData.Header.ProviderId == _demoSqlProvider)
                    {
                        if (subEventData.Properties.ContainsKey("query"))
                        {
                            string sqlQuery = subEventData.Properties["query"] as string;
                            sb.AppendLine(sqlQuery);
                        }

                    }
                });
            }
            return sb.ToString();            
        }

        public List<EtwDataEventItem> BuildTree(List<EtwDataEvent> list)
        {
            var treeList = new List<EtwDataEventItem>();
            var contextStack = new Stack<EtwDataEventItem>();

            foreach (var etwEvent in list)
            {
                if (etwEvent.Header.ProviderId == _demoCommandProvider)
                {
                    switch (etwEvent.EventId)
                    {
                        case 1:
                            contextStack.Push(new EtwDataEventItem(etwEvent));
                            break;
                        case 2:
                            if (contextStack.Count != 0)
                            {
                                var currentContext = contextStack.Pop();
                                currentContext.Children.Add(new EtwDataEventItem(etwEvent));
                                treeList.Add(currentContext);
                            }
                            else
                            {
                                treeList.Add(new EtwDataEventItem(etwEvent));
                            }
                            break;
                        default:
                            if (contextStack.Count != 0)
                            {
                                var currentContext = contextStack.Peek();
                                currentContext.Children.Add(new EtwDataEventItem(etwEvent));
                            }
                            else
                            {
                                treeList.Add(new EtwDataEventItem(etwEvent));
                            }
                            break;
                    }
                }
                else
                {
                    if (contextStack.Count != 0)
                    {
                        var currentContext = contextStack.Peek();
                        currentContext.Children.Add(new EtwDataEventItem(etwEvent));
                    }
                    else
                    {
                        treeList.Add(new EtwDataEventItem(etwEvent));
                    }
                }
            }
            return treeList;
        }

    }
}
