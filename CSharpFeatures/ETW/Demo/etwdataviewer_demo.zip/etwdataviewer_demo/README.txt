ETW manifest needs to be registered before they can be used.
Do this under a visual studio command prompt running with admin privileges.

// Install
wevtutil.exe im EtwProducerSampleAppTracing.man

// Uninstall
wevtutil.exe um EtwProducerSampleAppTracing.man